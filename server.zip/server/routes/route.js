const Controller = require("../controllers/controller.js");

module.exports = (app) => {
};
