import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import HeroGif from "../assets/hero.gif";

export default function Home() {
  const navigate = useNavigate();

  useEffect(() => {
    const sections = document.querySelectorAll(".fade-on-scroll");

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("animate-fade-in-up");
          }
        });
      },
      { threshold: 0.3 }
    );

    sections.forEach((section) => observer.observe(section));

    return () => sections.forEach((section) => observer.unobserve(section));
  }, []);

  return (
    // PAGE SHOULD BE ALLOWED TO GROW
    <div className="relative w-full min-h-screen overflow-x-hidden">

      {/* HERO — stays full screen */}
      <section className="relative w-full h-screen">
        <img
          src={HeroGif}
          alt="Learning Platform"
          className="h-full w-full object-cover"
        />

        <div className="absolute inset-0 flex items-center pl-16 text-white">
          <div className="space-y-6 animate-slide-in-left">
            <h1 className="text-5xl md:text-6xl font-bold">
              Start Your <br /> Coding Adventure
            </h1>

            <p className="text-xl md:text-2xl">
              Beginner friendly coding courses and projects
            </p>

            <button
              onClick={() => navigate("/auth")}
              className="px-6 py-3 bg-gradient-to-r from-blue-500 to-green-300 hover:bg-blue-700 transition"
            >
              GET STARTED
            </button>
          </div>
        </div>
      </section>

      {/* NEXT SECTION — scrolls normally */}
      <section className="relative w-full bg-gray-900 text-white py-20 fade-on-scroll">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-12 px-6">

          <div className="flex flex-col items-center text-center space-y-4">
            <div className="text-6xl">✨</div>
            <h2 className="text-2xl font-bold">Features</h2>
            <ul className="space-y-2 text-lg">
              <li>Beginner-friendly tutorials</li>
              <li>Project-based learning</li>
              <li>Community support</li>
              <li>Quizzes & challenges</li>
            </ul>
          </div>

          <div className="flex flex-col items-center text-center space-y-4">
            <div className="text-6xl">🌟</div>
            <h2 className="text-2xl font-bold">Purpose</h2>
            <p className="text-lg">
              Make coding accessible, fun, and practical for everyone.
            </p>
          </div>

          <div className="flex flex-col items-center text-center space-y-4">
            <div className="text-6xl">💡</div>
            <h2 className="text-2xl font-bold">Problem Solved</h2>
            <p className="text-lg">
              EduTech gives beginners a clear structured learning path.
            </p>
          </div>

        </div>
      </section>

      <style>{`
        @keyframes slide-in-left {
          0% { transform: translateX(-100%); opacity: 0; }
          100% { transform: translateX(0); opacity: 1; }
        }
        .animate-slide-in-left {
          animation: slide-in-left 1s ease-out forwards;
        }

        @keyframes fade-in-up {
          0% { transform: translateY(50px); opacity: 0; }
          100% { transform: translateY(0); opacity: 1; }
        }
        .animate-fade-in-up {
          animation: fade-in-up 1s ease-out forwards;
        }
      `}</style>
    </div>
  );
}
